# BookMarket BGT

BookMarket BGT është një aplikacion për nxënësit që duan të shesin ose dhurojnë libra të përdorur.

## Funksionalitetet
- Login dhe regjistrim me Supabase Auth
- Shfaqja e librave në listë
- Shtimi i një libri të ri
- Filtrat: Të gjitha / Në shitje / Të shitura / Të miat
- Pronari mund ta shënojë librin si “U shit”
- Pronari mund ta fshijë librin
- Dark mode
- Lista rifreskohet automatikisht

## Screenshot-e
- lista.png
- forma.png
- detajet.png

## Si ekzekutohet
1. Ekzekutohet SQL-i nga Day5_SQL.txt në Supabase.
2. Vendosen supabaseUrl dhe supabaseKey në main.dart.
3. Projekti hapet në FlutLab.
4. Shtypet Run.

## Çka do të shtoja më vonë
- Foto për secilin libër
- Kërkim sipas titullit ose lëndës